<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require('configuracao/conexao.php');

$filial = $GLOBALS['FILIAL_USUARIO'] ?? '100'; // fallback para 100

try {
	 $dataSelecionada = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');
    $query = "
	SELECT
    RTRIM(F.NUM_CARGA) AS NUM_CARGA,
    F.PLACA,
    PR.Descricao AS ROTAS,
    CAST(F.DATA_V1 AS DATE) AS DATA_CARREGAMENTO,
    SUM(IPVE.QTDE_PRI) AS QTDE_PRIMARIA_PEDIDO,
    SUM(IROS.QTDE_PRI) AS QTDE_PRIMARIA_ROMANEIO,
    COUNT(DISTINCT PVE.CHAVE_FATO) AS TOTAL_PEDIDOS,
	MAX(HORARIO.DATA_HORA_FINAL) AS HORA_FINAL,
    COUNT(DISTINCT NF.CHAVE_FATO) +
    CASE WHEN PTC.CHAVE_FATO IS NOT NULL THEN 1 ELSE 0 END AS TOTAL_NF

FROM TBMOVTOFRETE F
LEFT JOIN TBPERCURSO PR ON PR.COD_PERCURSO = F.COD_PERCURSO
LEFT JOIN TBLOCALIDADE ORIG ON ORIG.COD_LOCALIDADE = F.COD_LOCAL_ORIG
LEFT JOIN TBLOCALIDADE DEST ON DEST.COD_LOCALIDADE = F.COD_LOCAL_DEST
LEFT JOIN TBCADASTROGERAL MOT ON MOT.COD_CADASTRO = F.COD_MOTORISTA

-- Pedidos
INNER JOIN TBSAIDAS PVE ON PVE.CHAVE_FATO_FRETE = F.CHAVE_FATO_FRETE
INNER JOIN TBSAIDASITEM IPVE ON IPVE.CHAVE_FATO = PVE.CHAVE_FATO
INNER JOIN TBTIPOMVESTOQUE TMV ON TMV.COD_TIPO_MV = PVE.COD_TIPO_MV AND TMV.PERFIL_TMV IN ('VDA0101','VDA0102')

-- Romaneio
LEFT JOIN TBSAIDAS ROS ON ROS.CHAVE_FATO_ORIG_UN = PVE.CHAVE_FATO
LEFT JOIN TBSAIDASITEM IROS ON IROS.CHAVE_FATO = ROS.CHAVE_FATO AND IROS.COD_PRODUTO = IPVE.COD_PRODUTO

-- Notas fiscais vinculadas ao ROS
LEFT JOIN TBSAIDAS NF ON NF.CHAVE_FATO_ORIG_UN = ROS.CHAVE_FATO AND NF.COD_DOCTO IN ('NE', 'NEE')

-- PTC vinculado ao ROS
LEFT JOIN (
    SELECT DISTINCT TBI.Chave_fato_orig, PTC.Chave_fato
    FROM tbSaidasItem TBI
    INNER JOIN tbSaidas PTC
        ON PTC.Chave_fato = TBI.Chave_fato
        AND PTC.COD_DOCTO = 'PTC'
) PTC ON PTC.Chave_fato_orig = ROS.Chave_fato

LEFT JOIN (
			SELECT
			MAX(R.DATAHORA) AS DATA_HORA_FINAL,
			S.CHAVE_FATO_FRETE
			FROM TBSAIDASITEMROM R
			INNER JOIN TBSAIDAS S ON S.CHAVE_FATO = R.CHAVE_FATO
			GROUP BY S.CHAVE_FATO_FRETE
) HORARIO ON HORARIO.CHAVE_FATO_FRETE = ROS.CHAVE_FATO_FRETE

WHERE 
    F.COD_FILIAL = :filialSelecionada
    AND F.DATA_V1 = :dataSelecionada

GROUP BY
    F.COD_FILIAL,
    F.SERIE_CARGA,
    F.NUM_CARGA,
    F.PLACA,
    PR.Descricao,
    F.DATA_MOVTO,
    F.DATA_V1,
    F.DATA_V2,
    IPVE.COD_UNIDADE,
    PTC.CHAVE_FATO
";

    $stmt = $pdoS->prepare($query);
   $stmt->execute([
    'dataSelecionada' => $dataSelecionada,
    'filialSelecionada' => $filial
	]);
    $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Se `$dados` for vazio, retorna um array vazio em JSON
    echo json_encode($dados ?: [], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
